﻿using System.Collections.Generic;

namespace CueController3.Model
{
    class ControllerNames
    {
        List<string> ctrlList = new List<string>();

        public ControllerNames()
        {
            for (int i = 1; i < 9; ++i)
                ctrlList.Add("Fader " + i);

            for (int i = 1; i < 9; ++i)
                ctrlList.Add("Knob " + i);

            for (int i = 1; i < 9; ++i)
                ctrlList.Add("S Button " + i);

            ctrlList.Add("Play Button");
            ctrlList.Add("Stop Button");
            ctrlList.Add("RWD Button");
            ctrlList.Add("FWD Button");
            ctrlList.Add("Record Button");
            ctrlList.Add("Cycle Button");

            for (int i = 1; i < 9; ++i)
                ctrlList.Add("M Button " + i);

            ctrlList.Add("Track Left");
            ctrlList.Add("Track Right");
            ctrlList.Add("Set Marker");
            ctrlList.Add("Marker Left");
            ctrlList.Add("Marker Right");

            for (int i = 1; i < 9; ++i)
                ctrlList.Add("R Button " + i);
        }

       public List<string> GetNames()
        {
            return ctrlList;
        }

        public string GetName(int nr)
        {
            return ctrlList[nr];
        }

        public int GetNr(string name)
        {
            return ctrlList.IndexOf(name);
        }
    }
}

