﻿using CueController3.Model;
using System.IO;
using System.Xml;

namespace CueController3.Controller.MyMidi
{
    class MidiCtrlXml
    {

        public static ControllerValues Read()
        {
            ControllerValues ctrlVals = new ControllerValues();

            if (!File.Exists("controllerMapping.xml"))
            {
                ControllerNames ctrlNames = new ControllerNames();

                using (XmlWriter writer = XmlWriter.Create("controllerMapping.xml"))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("ControllerMapping");

                    foreach (string name in ctrlNames.GetNames())
                    {
                        writer.WriteStartElement("Controller");
                        writer.WriteElementString("Name", name);
                        writer.WriteElementString("Min", "0");
                        writer.WriteElementString("Max", "1");
                        writer.WriteElementString("Interp.", "0");
                        writer.WriteElementString("PbCmdVal", "");
                        writer.WriteElementString("PbCmdOn", "");
                        writer.WriteElementString("PbCmdOff", "");
                        writer.WriteElementString("CcCmdOn", "");
                        writer.WriteElementString("CcCmdOff", "");
                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }
            }
            else
            {
                try
                {
                    using (XmlReader reader = XmlReader.Create("controllerMapping.xml"))
                    {
                        int i = -1;

                        while (reader.Read())
                        {
                            if (reader.IsStartElement())
                            {
                                if (reader.Name == "Controller") i++;
                                else if (!reader.IsEmptyElement)
                                {
                                    switch (reader.Name)
                                    {
                                        case "Min":
                                            reader.Read();
                                            ctrlVals.min[i] = int.Parse(reader.Value);
                                            break;
                                        case "Max":
                                            reader.Read();
                                            ctrlVals.max[i] = int.Parse(reader.Value);
                                            break;
                                        case "Interp.":
                                            reader.Read();
                                            ctrlVals.interp[i] = int.Parse(reader.Value);
                                            break;
                                        case "PbCmdVal":
                                            reader.Read();
                                            PbCmdArg pbCmd = PbCmdArg.GetPbCmdArg(reader.Value);
                                            ctrlVals.pbCmdVal[i] = pbCmd;
                                            break;
                                        case "PbCmdOn":
                                            reader.Read();
                                            PbCmd pbCmd1 = PbCmd.GetPbCmd(reader.Value);
                                            ctrlVals.pbCmdOn[i] = pbCmd1;
                                            break;
                                        case "PbCmdOff":
                                            reader.Read();
                                            PbCmd pbCmd2 = PbCmd.GetPbCmd(reader.Value);
                                            ctrlVals.pbCmdOff[i] = pbCmd2;
                                            break;
                                        case "CcCmdOn":
                                            reader.Read();
                                            ctrlVals.ccCmdOn[i] = reader.Value;
                                            break;
                                        case "CcCmdOff":
                                            reader.Read();
                                            ctrlVals.ccCmdOff[i] = reader.Value;
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch { LogCtrl.Error("Can't read controllerMapping.xml"); }
            }
            return ctrlVals;
        }

        public static bool Write(ControllerValues ctrlVals)
        {
            try
            {
                ControllerNames ctrlNames = new ControllerNames();

                using (XmlWriter writer = XmlWriter.Create("controllerMapping.xml"))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("ControllerMapping");

                    int i = 0;

                    foreach (string name in ctrlNames.GetNames())
                    {
                        writer.WriteStartElement("Controller");
                        writer.WriteElementString("Name", name);
                        writer.WriteElementString("Min", ctrlVals.min[i].ToString());
                        writer.WriteElementString("Max", ctrlVals.max[i].ToString());
                        writer.WriteElementString("Interp.", ctrlVals.interp[i].ToString());
                        if (ctrlVals.pbCmdVal[i] == null) writer.WriteElementString("PbCmdVal", "");
                        else writer.WriteElementString("PbCmdVal", ctrlVals.pbCmdVal[i].name);
                        if (ctrlVals.pbCmdOn[i] == null) writer.WriteElementString("PbCmdOn", "");
                        else writer.WriteElementString("PbCmdOn", ctrlVals.pbCmdOn[i].name);
                        if (ctrlVals.pbCmdOff[i] == null) writer.WriteElementString("PbCmdOff", "");
                        else writer.WriteElementString("PbCmdOff", ctrlVals.pbCmdOff[i].name);

                        writer.WriteElementString("CcCmdOn", ctrlVals.ccCmdOn[i]);
                        writer.WriteElementString("CcCmdOff", ctrlVals.ccCmdOff[i]);

                        writer.WriteEndElement();
                        ++i;
                    }
                    writer.WriteEndElement();
                    writer.WriteEndDocument();

                    return true;
                }
            }
            catch { return false; }
        }
    }
}